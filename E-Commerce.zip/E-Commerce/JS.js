// Shopping Cart Logic
let cartCount = 0; // Represents the total number of items (including quantities)
const cartItems = [];

// Function to toggle the shopping cart overlay
function toggleCart() {
  const cartOverlay = document.getElementById('cartOverlay');
  cartOverlay.classList.toggle('show');
}

// Function to add a product to the cart
function addToCart(productName, productPrice, productImage) {
  // Check if the product already exists in the cart
  const existingProduct = cartItems.find(
    (item) => item.name === productName && item.price === productPrice
  );

  if (existingProduct) {
    // If the product exists, increase its quantity
    existingProduct.quantity++;
  } else {
    // If the product doesn't exist, add it to the cart with quantity 1
    const cartItem = { name: productName, price: productPrice, image: productImage, quantity: 1 };
    cartItems.push(cartItem);
  }

  // Increase the total cart count by 1
  cartCount++;
  document.querySelector('.cart-count').textContent = cartCount;

  // Update the cart UI
  updateCartUI();
}

// Function to update the cart UI
function updateCartUI() {
  const cartItemsContainer = document.getElementById('cartItems');
  cartItemsContainer.innerHTML = '';

  cartItems.forEach((item, index) => {
    const cartItemElement = document.createElement('div');
    cartItemElement.className = 'cart-item';
    cartItemElement.innerHTML = `
      <img src="${item.image}" alt="${item.name}" />
      <h3>${item.name}</h3>
      <p>${item.price} x ${item.quantity}</p>
      <button class="delete-item" onclick="deleteCartItem(${index})">Delete</button>
    `;
    cartItemsContainer.appendChild(cartItemElement);
  });
}

// Function to delete a cart item
function deleteCartItem(index) {
  const deletedItem = cartItems.splice(index, 1)[0]; // Remove the item from the cart
  cartCount -= deletedItem.quantity; // Decrease the cart count by the quantity of the deleted item
  document.querySelector('.cart-count').textContent = cartCount;
  updateCartUI(); // Update the cart UI
}

// Function to open the product details modal
function openProductModal(productName, productPrice, productImage) {
  const modal = document.getElementById('productModal');
  document.getElementById('modalProductName').textContent = productName;
  document.getElementById('modalProductImage').src = productImage;
  document.getElementById('modalProductPrice').textContent = productPrice;
  modal.classList.add('show');
}

// Function to close the product details modal
function closeProductModal() {
  const modal = document.getElementById('productModal');
  modal.classList.remove('show');
}

// Function to add to cart from modal
function addToCartFromModal() {
  const productName = document.getElementById('modalProductName').textContent;
  const productPrice = document.getElementById('modalProductPrice').textContent;
  const productImage = document.getElementById('modalProductImage').src;
  addToCart(productName, productPrice, productImage);
  closeProductModal();
}

// Function to handle "Add to Cart" button clicks
function handleAddToCart(event) {
  event.stopPropagation(); // Prevent the card click event from firing
  const productCard = event.currentTarget.closest('.product-card');
  const productName = productCard.querySelector('h3').textContent;
  const productPrice = productCard.querySelector('p').textContent;
  const productImage = productCard.querySelector('img').src;
  addToCart(productName, productPrice, productImage);
}

// Function to handle product card clicks
function handleProductCardClick(event) {
  const productCard = event.currentTarget;
  const productName = productCard.querySelector('h3').textContent;
  const productPrice = productCard.querySelector('p').textContent;
  const productImage = productCard.querySelector('img').src;
  openProductModal(productName, productPrice, productImage);
}

// Function to initialize event listeners
function initializeEventListeners() {
  // Event Listeners for Add to Cart Buttons
  const addToCartButtons = document.querySelectorAll('.product-card button');
  addToCartButtons.forEach((button) => {
    button.removeEventListener('click', handleAddToCart); // Remove existing listener (if any)
    button.addEventListener('click', handleAddToCart); // Add new listener
  });

  // Event Listeners for Product Cards to Open Modal
  const productCards = document.querySelectorAll('.product-card');
  productCards.forEach((card) => {
    card.removeEventListener('click', handleProductCardClick); // Remove existing listener (if any)
    card.addEventListener('click', handleProductCardClick); // Add new listener
  });

  // Event Listener for Add to Cart Button in Modal
  const modalAddToCartButton = document.querySelector('.modal button');
  if (modalAddToCartButton) {
    modalAddToCartButton.removeEventListener('click', addToCartFromModal); // Remove existing listener (if any)
    modalAddToCartButton.addEventListener('click', addToCartFromModal); // Add new listener
  }

  // Event Listener for Close Modal Button
  const closeModalButton = document.querySelector('.modal button:last-child');
  if (closeModalButton) {
    closeModalButton.removeEventListener('click', closeProductModal); // Remove existing listener (if any)
    closeModalButton.addEventListener('click', closeProductModal); // Add new listener
  }
}

// Initialize event listeners when the DOM is fully loaded
document.addEventListener('DOMContentLoaded', initializeEventListeners);